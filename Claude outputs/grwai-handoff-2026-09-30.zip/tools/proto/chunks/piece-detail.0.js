const FRAME_ID = "3:121"; const CHUNK = 0;
const FONTS = ["P Regular","Semi Bold","Medium","P Italic","Regular"];
const IMG = {"adbbfd1fe3d2752a":"adbbfd1fe3d2752af68447bffb638d8060679ec8"};
const ICONS = {"9d403b186c":"14:11","dc704a1382":"14:284","d817b9c845":"15:8"};
const UNITS = [{"k":"F","n":"box","x":0,"y":0,"w":390,"h":844,"bg":"#ffffff","c":[{"k":"F","n":"box","x":0,"y":0,"w":390,"h":61,"st":{"c":"#000000","a":1,"w":[0,0,1,0],"dashed":false},"c":[{"k":"S","n":"chevron-left","x":22,"y":18,"w":24,"h":24,"ic":"9d403b186c","op":1},{"k":"T","n":"heading","x":60,"y":17,"w":270,"h":26,"runs":[{"s":"Top","f":"P Regular","fs":20,"c":"#0f0f0f","lh":26}]}]},{"k":"F","n":"group","x":0,"y":61,"w":390,"h":783,"clip":1,"c":[{"k":"F","n":"group","x":0,"y":61,"w":390,"h":844,"c":[{"k":"F","n":"image","x":24,"y":85,"w":342,"h":342,"img":"adbbfd1fe3d2752a","clip":1},{"k":"F","n":"group","x":24,"y":451,"w":342,"h":50,"c":[{"k":"T","n":"Top","x":24,"y":451,"w":342,"h":14,"runs":[{"s":"Top","f":"Semi Bold","fs":11,"c":"#6b6b6b","lh":14,"ls":0.88,"u":1}]},{"k":"F","n":"group","x":24,"y":473,"w":342,"h":28,"c":[{"k":"F","n":"box","x":24,"y":473,"w":57,"h":28,"bg":"#ffffff","rad":[14,14,14,14],"st":{"c":"#eae7e1","a":1,"w":[1,1,1,1],"dashed":false},"c":[{"k":"T","n":"work","x":37,"y":480.5,"w":31,"h":13,"runs":[{"s":"work","f":"Medium","fs":13,"c":"#0f0f0f","lh":13}]}]},{"k":"F","n":"box","x":89,"y":473,"w":66,"h":28,"bg":"#ffffff","rad":[14,14,14,14],"st":{"c":"#eae7e1","a":1,"w":[1,1,1,1],"dashed":false},"c":[{"k":"T","n":"dinner","x":102,"y":480.5,"w":40,"h":13,"runs":[{"s":"dinner","f":"Medium","fs":13,"c":"#0f0f0f","lh":13}]}]}]}]},{"k":"F","n":"group","x":24,"y":525,"w":342,"h":184,"c":[{"k":"F","n":"box","x":24,"y":525,"w":342,"h":124,"bg":"#faf7f2","rad":[16,16,16,16],"clip":1,"c":[{"k":"F","n":"group","x":44,"y":545,"w":302,"h":32,"c":[{"k":"F","n":"group","x":44,"y":545,"w":32,"h":32,"rad":[16,16,16,16],"c":[{"k":"F","n":"group","x":44,"y":545,"w":32,"h":32,"bg":"#0f0f0f","clip":1,"c":[{"k":"T","n":"I","x":57.5,"y":552.6,"w":5,"h":16.8,"runs":[{"s":"I","f":"P Italic","fs":16,"c":"#ffffff","lh":16.8}]}]},{"k":"F","n":"box","x":65,"y":566,"w":12,"h":12,"bg":"#ffffff","rad":[6,6,6,6],"c":[{"k":"F","n":"box","x":67,"y":568,"w":8,"h":8,"bg":"#2f7a4d","rad":[4,4,4,4]}]}]},{"k":"T","n":"Iris","x":88,"y":554,"w":23.5,"h":14,"runs":[{"s":"Iris","f":"Semi Bold","fs":11,"c":"#6b6b6b","lh":14,"ls":0.88,"u":1}]}]},{"k":"T","n":"Add a full-body photo first and I'll sho","x":44,"y":589,"w":302,"h":40,"runs":[{"s":"Add a full-body photo first and I'll show you in this.","f":"Regular","fs":14,"c":"#0f0f0f","lh":20}]}]},{"k":"F","n":"button","x":24,"y":661,"w":342,"h":48,"bg":"#ffffff","rad":[12,12,12,12],"st":{"c":"#eae7e1","a":1,"w":[1,1,1,1],"dashed":false},"c":[{"k":"T","n":"Add photo","x":155,"y":676,"w":80,"h":18,"runs":[{"s":"Add photo","f":"Medium","fs":16,"c":"#0f0f0f","lh":18}]}]}]},{"k":"F","n":"button","x":24,"y":733,"w":100,"h":28,"rad":[14,14,14,14],"st":{"c":"#0f0f0f","a":1,"w":[1,1,1,1],"dashed":false},"c":[{"k":"F","n":"group","x":37,"y":740,"w":74,"h":14,"c":[{"k":"S","n":"pencil","x":37,"y":740,"w":14,"h":14,"ic":"dc704a1382","op":1},{"k":"T","n":"Edit tags","x":59,"y":740.5,"w":52,"h":13,"runs":[{"s":"Edit tags","f":"Medium","fs":13,"c":"#0f0f0f","lh":13}]}]}]},{"k":"F","n":"button","x":24,"y":809,"w":342,"h":48,"bg":"#ffffff","rad":[12,12,12,12],"st":{"c":"#f4d9d9","a":1,"w":[1,1,1,1],"dashed":false},"c":[{"k":"F","n":"group","x":116,"y":824,"w":158,"h":18,"c":[{"k":"S","n":"trash","x":116,"y":824,"w":18,"h":18,"ic":"d817b9c845","op":1},{"k":"T","n":"Remove from closet","x":142,"y":824,"w":132,"h":18,"runs":[{"s":"Remove from closet","f":"Medium","fs":14,"c":"#b83a3a","lh":18}]}]}]}]}]}]}];

const FRAME = await figma.getNodeByIdAsync(FRAME_ID);
if (!FRAME) throw new Error('frame missing');
const fontOf = (f) => f.startsWith('P ') ? { family: 'Playfair Display', style: f.slice(2) } : { family: 'Inter', style: f };
const bgOf = (bg) => typeof bg === 'string' ? { c: bg, a: 1 } : bg;
const loaded = {}; async function font(f) { const k = f.family + '|' + f.style; if (loaded[k] !== undefined) return loaded[k]; try { await figma.loadFontAsync(f); loaded[k] = f; } catch (e) { const fb = { family: 'Inter', style: /Italic/.test(f.style) ? 'Italic' : (f.style === 'Medium' || f.style === 'Semi Bold' || f.style === 'Bold') ? f.style : 'Regular' }; try { await figma.loadFontAsync(fb); loaded[k] = fb; } catch (e2) { await figma.loadFontAsync({ family: 'Inter', style: 'Regular' }); loaded[k] = { family: 'Inter', style: 'Regular' }; } } return loaded[k]; }
for (const f of FONTS) await font(fontOf(f));
const hex = (h) => ({ r: parseInt(h.slice(1, 3), 16) / 255, g: parseInt(h.slice(3, 5), 16) / 255, b: parseInt(h.slice(5, 7), 16) / 255 });
const isHot = (c) => c.name.startsWith('→') || c.name.startsWith('swipe →') || c.name.startsWith('Reference');
if (CHUNK === 0) {
  const imgFill = FRAME.fills.find((f) => f.type === 'IMAGE');
  for (const c of [...FRAME.children]) if (!isHot(c) || c.name.startsWith('Reference')) c.remove();
  FRAME.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }]; FRAME.clipsContent = true;
  if (imgFill) { const ref = figma.createRectangle(); ref.name = 'Reference screenshot (hidden)'; ref.resize(390, 844); ref.fills = [imgFill]; ref.visible = false; ref.locked = true; FRAME.insertChild(0, ref); }
}
function gradTransform(angle) { const t = angle * Math.PI / 180; const dx = Math.sin(t), dy = -Math.cos(t); const s = 1 / (Math.abs(dx) + Math.abs(dy) || 1); return [[dx * s, dy * s, 0.5 - 0.5 * (dx + dy) * s], [-dy * s, dx * s, 0.5 + 0.5 * (dy - dx) * s]]; }
function fillsOf(n) {
  const out = [];
  if (n.bg) { const b = bgOf(n.bg); out.push({ type: 'SOLID', color: hex(b.c), opacity: b.a }); }
  if (n.grad) out.push({ type: 'GRADIENT_LINEAR', gradientTransform: gradTransform(n.grad.angle), gradientStops: n.grad.stops.map((s) => ({ position: s.p, color: { ...hex(s.c), a: s.a } })) });
  if (n.img) { const hsh = IMG[n.img]; if (hsh) out.push({ type: 'IMAGE', imageHash: hsh, scaleMode: n.fit || 'FILL' }); else if (!out.length) out.push({ type: 'SOLID', color: { r: 0.93, g: 0.92, b: 0.9 } }); }
  return out;
}
function decorate(node, n) {
  node.fills = fillsOf(n);
  if (n.rad) { node.topLeftRadius = n.rad[0]; node.topRightRadius = n.rad[1]; node.bottomRightRadius = n.rad[2]; node.bottomLeftRadius = n.rad[3]; }
  if (n.st) { node.strokes = [{ type: 'SOLID', color: hex(n.st.c), opacity: n.st.a }]; node.strokeAlign = 'INSIDE'; const [t, r, b, l] = n.st.w; if (t === r && r === b && b === l) node.strokeWeight = t; else { node.strokeTopWeight = t; node.strokeRightWeight = r; node.strokeBottomWeight = b; node.strokeLeftWeight = l; } if (n.st.dashed) node.dashPattern = [6, 4]; }
  if (n.sh) node.effects = n.sh.map((s) => ({ type: 'DROP_SHADOW', color: { ...hex(s.c), a: s.a }, offset: { x: s.x, y: s.y }, radius: s.b, spread: s.s, visible: true, blendMode: 'NORMAL' }));
  if (n.op) node.opacity = n.op;
}
async function makeText(n) {
  const t = figma.createText();
  const f0 = await font(fontOf(n.runs[0].f)); t.fontName = f0;
  const chars = n.runs.map((r) => r.s).join('');
  t.characters = chars;
  let pos = 0;
  for (const r of n.runs) {
    const end = pos + r.s.length; if (end > pos) {
      t.setRangeFontName(pos, end, await font(fontOf(r.f)));
      t.setRangeFontSize(pos, end, r.fs);
      t.setRangeFills(pos, end, [{ type: 'SOLID', color: hex(r.c), opacity: r.a === undefined ? 1 : r.a }]);
      t.setRangeLineHeight(pos, end, r.lh ? { unit: 'PIXELS', value: r.lh } : { unit: 'AUTO' });
      t.setRangeLetterSpacing(pos, end, { unit: 'PIXELS', value: r.ls || 0 });
      if (r.u) t.setRangeTextCase(pos, end, 'UPPER');
    }
    pos = end;
  }
  t.textAlignHorizontal = n.al || 'LEFT'; t.textAlignVertical = 'TOP';
  const pad = n.pad || [0, 0, 0, 0];
  const boxW = Math.max(2, n.w - pad[1] - pad[3]), boxH = Math.max(2, n.h - pad[0] - pad[2]);
  const lineH = n.runs[0].lh || n.runs[0].fs * 1.3;
  let dx = pad[3];
  if (boxH <= lineH + 1.5 && !chars.includes('\n')) {
    // single line in the app: never let Figma's slightly different metrics wrap it
    t.textAutoResize = 'WIDTH_AND_HEIGHT';
    if (n.al === 'CENTER') dx += (boxW - t.width) / 2; else if (n.al === 'RIGHT') dx += boxW - t.width;
  } else {
    t.textAutoResize = 'NONE'; t.resize(boxW + 2, boxH);
    t.textAutoResize = 'HEIGHT';
  }
  t.name = n.n || chars.slice(0, 40);
  return { node: t, dx, dy: pad[0] };
}
let count = 0;
async function make(n, parent, px, py) {
  let node, dx = 0, dy = 0;
  if (n.k === 'S') { const comp = ICONS[n.ic] ? await figma.getNodeByIdAsync(ICONS[n.ic]) : null; if (comp && comp.type === 'COMPONENT') { node = comp.createInstance(); } else { node = figma.createFrame(); node.fills = []; node.resize(Math.max(1, n.w), Math.max(1, n.h)); } node.name = n.n || 'icon'; if (n.op) node.opacity = n.op; }
  else if (n.k === 'T') { const r = await makeText(n); node = r.node; dx = r.dx; dy = r.dy; if (n.op) node.opacity = n.op; }
  else if (n.c && n.c.length) { node = figma.createFrame(); node.resize(Math.max(1, n.w), Math.max(1, n.h)); decorate(node, n); node.clipsContent = !!n.clip; node.name = n.n || 'group'; }
  else { node = figma.createRectangle(); node.resize(Math.max(1, n.w), Math.max(1, n.h)); decorate(node, n); node.name = n.n || (n.img ? 'image' : 'box'); }
  node.x = n.x - px + dx; node.y = n.y - py + dy;
  parent.appendChild(node); count++;
  if (n.rot) { const th = n.rot * Math.PI / 180, c = Math.cos(th), s = Math.sin(th); const cx = n.x + n.w / 2, cy = n.y + n.h / 2; const tlx = cx + (-n.w / 2) * c - (-n.h / 2) * s, tly = cy + (-n.w / 2) * s + (-n.h / 2) * c; node.relativeTransform = [[c, -s, tlx - px], [s, c, tly - py]]; }
  if (n.c) for (const c of n.c) await make(c, node, n.x, n.y);
  return node;
}
const created = [];
for (const u of UNITS) created.push((await make(u, FRAME, 0, 0)).id);
// hotspots back on top
for (const c of [...FRAME.children]) if (c.name.startsWith('→') || c.name.startsWith('swipe →')) FRAME.appendChild(c);
return { frame: FRAME_ID, chunk: CHUNK, nodes: count, created: created.length };
