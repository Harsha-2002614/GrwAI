const FRAME_ID = "3:77"; const CHUNK = 0;
const FONTS = ["P Regular","Semi Bold","Medium","P Italic"];
const IMG = {"76af5d5bd35395ff":"76af5d5bd35395ffcbaf3a06f272400804a0c1ce"};
const ICONS = {"9d403b186c":"14:11","c0b0b0da12":"14:110"};
const UNITS = [{"k":"F","n":"box","x":0,"y":0,"w":390,"h":844,"bg":"#ffffff","c":[{"k":"F","n":"group","x":0,"y":0,"w":390,"h":56,"c":[{"k":"S","n":"chevron-left","x":22,"y":16,"w":24,"h":24,"ic":"9d403b186c","op":1},{"k":"T","n":"City Stroll","x":52,"y":15,"w":286,"h":26,"runs":[{"s":"City Stroll","f":"P Regular","fs":20,"c":"#0f0f0f","lh":26}],"al":"CENTER"}]},{"k":"F","n":"group","x":0,"y":56,"w":390,"h":788,"clip":1,"c":[{"k":"F","n":"group","x":0,"y":56,"w":390,"h":906,"c":[{"k":"F","n":"box","x":0,"y":56,"w":390,"h":520,"bg":"#f4f2ee","clip":1,"c":[{"k":"F","n":"image","x":0,"y":56,"w":390,"h":520,"img":"76af5d5bd35395ff","clip":1},{"k":"F","n":"group","x":16,"y":72,"w":206.1,"h":30,"rad":[15,15,15,15],"clip":1,"c":[{"k":"F","n":"box","x":16,"y":72,"w":206.1,"h":30,"bg":{"c":"#ffffff","a":0.85}},{"k":"T","n":"CASUAL · ERRAND-FRIENDLY","x":30,"y":80,"w":178.1,"h":14,"runs":[{"s":"CASUAL · ERRAND-FRIENDLY","f":"Semi Bold","fs":11,"c":"#0f0f0f","lh":14,"ls":0.88,"u":1}]}]},{"k":"F","n":"Save outfit","x":326,"y":72,"w":48,"h":48,"bg":{"c":"#ffffff","a":0.85},"rad":[24,24,24,24],"c":[{"k":"S","n":"heart","x":337,"y":83,"w":26,"h":26,"ic":"c0b0b0da12","op":1}]},{"k":"F","n":"group","x":0,"y":420,"w":390,"h":156,"c":[{"k":"F","n":"box","x":0,"y":420,"w":390,"h":156,"grad":{"angle":180,"stops":[{"c":"#0f0f0f","a":0,"p":0},{"c":"#000000","a":1,"p":1}]}},{"k":"T","n":"SOHO · SOFT AFTERNOON","x":16,"y":546,"w":358,"h":14,"runs":[{"s":"SOHO · SOFT AFTERNOON","f":"Semi Bold","fs":11,"c":"#ffffff","lh":14,"ls":0.88,"u":1}]}]}]},{"k":"F","n":"group","x":0,"y":576,"w":390,"h":338,"c":[{"k":"F","n":"group","x":24,"y":596,"w":342,"h":30,"c":[{"k":"T","n":"heading","x":24,"y":596,"w":289,"h":30,"runs":[{"s":"City Stroll","f":"P Regular","fs":24,"c":"#0f0f0f","lh":30,"ls":-0.24}]},{"k":"T","n":"$218","x":329,"y":605,"w":37,"h":20,"runs":[{"s":"$","f":"Medium","fs":16,"c":"#0f0f0f","lh":20},{"s":"218","f":"Medium","fs":16,"c":"#0f0f0f","lh":20}]}]},{"k":"T","n":"Mariniere reads polished without trying.","x":24,"y":638,"w":342,"h":52,"runs":[{"s":"Mariniere reads polished without trying. Indigo softens the contrast.","f":"P Italic","fs":17,"c":"#6b6b6b","lh":26}]},{"k":"F","n":"group","x":24,"y":722,"w":342,"h":94,"c":[{"k":"T","n":"The pieces","x":24,"y":722,"w":342,"h":14,"runs":[{"s":"The pieces","f":"Semi Bold","fs":11,"c":"#6b6b6b","lh":14,"ls":0.88,"u":1}]},{"k":"F","n":"group","x":24,"y":748,"w":342,"h":68,"c":[{"k":"F","n":"box","x":24,"y":748,"w":109.6,"h":30,"bg":"#f4f2ee","rad":[15,15,15,15],"c":[{"k":"T","n":"STRIPED KNIT","x":36,"y":756,"w":85.6,"h":14,"runs":[{"s":"STRIPED KNIT","f":"Semi Bold","fs":11,"c":"#0f0f0f","lh":14,"ls":0.88,"u":1}]}]},{"k":"F","n":"box","x":141.6,"y":748,"w":122.5,"h":30,"bg":"#f4f2ee","rad":[15,15,15,15],"c":[{"k":"T","n":"VINTAGE DENIM","x":153.6,"y":756,"w":98.5,"h":14,"runs":[{"s":"VINTAGE DENIM","f":"Semi Bold","fs":11,"c":"#0f0f0f","lh":14,"ls":0.88,"u":1}]}]},{"k":"F","n":"box","x":24,"y":786,"w":134.3,"h":30,"bg":"#f4f2ee","rad":[15,15,15,15],"c":[{"k":"T","n":"WHITE SNEAKERS","x":36,"y":794,"w":110.3,"h":14,"runs":[{"s":"WHITE SNEAKERS","f":"Semi Bold","fs":11,"c":"#0f0f0f","lh":14,"ls":0.88,"u":1}]}]},{"k":"F","n":"box","x":166.3,"y":786,"w":99.9,"h":30,"bg":"#f4f2ee","rad":[15,15,15,15],"c":[{"k":"T","n":"CROSSBODY","x":178.3,"y":794,"w":75.9,"h":14,"runs":[{"s":"CROSSBODY","f":"Semi Bold","fs":11,"c":"#0f0f0f","lh":14,"ls":0.88,"u":1}]}]}]}]}]}]}]}]}];

const FRAME = await figma.getNodeByIdAsync(FRAME_ID);
if (!FRAME) throw new Error('frame missing');
const fontOf = (f) => f.startsWith('P ') ? { family: 'Playfair Display', style: f.slice(2) } : { family: 'Inter', style: f };
const bgOf = (bg) => typeof bg === 'string' ? { c: bg, a: 1 } : bg;
const loaded = {}; async function font(f) { const k = f.family + '|' + f.style; if (loaded[k] !== undefined) return loaded[k]; try { await figma.loadFontAsync(f); loaded[k] = f; } catch (e) { const fb = { family: 'Inter', style: /Italic/.test(f.style) ? 'Italic' : (f.style === 'Medium' || f.style === 'Semi Bold' || f.style === 'Bold') ? f.style : 'Regular' }; try { await figma.loadFontAsync(fb); loaded[k] = fb; } catch (e2) { await figma.loadFontAsync({ family: 'Inter', style: 'Regular' }); loaded[k] = { family: 'Inter', style: 'Regular' }; } } return loaded[k]; }
for (const f of FONTS) await font(fontOf(f));
const hex = (h) => ({ r: parseInt(h.slice(1, 3), 16) / 255, g: parseInt(h.slice(3, 5), 16) / 255, b: parseInt(h.slice(5, 7), 16) / 255 });
const isHot = (c) => c.name.startsWith('→') || c.name.startsWith('swipe →') || c.name.startsWith('Reference');
if (CHUNK === 0) {
  const imgFill = FRAME.fills.find((f) => f.type === 'IMAGE');
  for (const c of [...FRAME.children]) if (!isHot(c) || c.name.startsWith('Reference')) c.remove();
  FRAME.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }]; FRAME.clipsContent = true;
  if (imgFill) { const ref = figma.createRectangle(); ref.name = 'Reference screenshot (hidden)'; ref.resize(390, 844); ref.fills = [imgFill]; ref.visible = false; ref.locked = true; FRAME.insertChild(0, ref); }
}
function gradTransform(angle) { const t = angle * Math.PI / 180; const dx = Math.sin(t), dy = -Math.cos(t); const s = 1 / (Math.abs(dx) + Math.abs(dy) || 1); return [[dx * s, dy * s, 0.5 - 0.5 * (dx + dy) * s], [-dy * s, dx * s, 0.5 + 0.5 * (dy - dx) * s]]; }
function fillsOf(n) {
  const out = [];
  if (n.bg) { const b = bgOf(n.bg); out.push({ type: 'SOLID', color: hex(b.c), opacity: b.a }); }
  if (n.grad) out.push({ type: 'GRADIENT_LINEAR', gradientTransform: gradTransform(n.grad.angle), gradientStops: n.grad.stops.map((s) => ({ position: s.p, color: { ...hex(s.c), a: s.a } })) });
  if (n.img) { const hsh = IMG[n.img]; if (hsh) out.push({ type: 'IMAGE', imageHash: hsh, scaleMode: n.fit || 'FILL' }); else if (!out.length) out.push({ type: 'SOLID', color: { r: 0.93, g: 0.92, b: 0.9 } }); }
  return out;
}
function decorate(node, n) {
  node.fills = fillsOf(n);
  if (n.rad) { node.topLeftRadius = n.rad[0]; node.topRightRadius = n.rad[1]; node.bottomRightRadius = n.rad[2]; node.bottomLeftRadius = n.rad[3]; }
  if (n.st) { node.strokes = [{ type: 'SOLID', color: hex(n.st.c), opacity: n.st.a }]; node.strokeAlign = 'INSIDE'; const [t, r, b, l] = n.st.w; if (t === r && r === b && b === l) node.strokeWeight = t; else { node.strokeTopWeight = t; node.strokeRightWeight = r; node.strokeBottomWeight = b; node.strokeLeftWeight = l; } if (n.st.dashed) node.dashPattern = [6, 4]; }
  if (n.sh) node.effects = n.sh.map((s) => ({ type: 'DROP_SHADOW', color: { ...hex(s.c), a: s.a }, offset: { x: s.x, y: s.y }, radius: s.b, spread: s.s, visible: true, blendMode: 'NORMAL' }));
  if (n.op) node.opacity = n.op;
}
async function makeText(n) {
  const t = figma.createText();
  const f0 = await font(fontOf(n.runs[0].f)); t.fontName = f0;
  const chars = n.runs.map((r) => r.s).join('');
  t.characters = chars;
  let pos = 0;
  for (const r of n.runs) {
    const end = pos + r.s.length; if (end > pos) {
      t.setRangeFontName(pos, end, await font(fontOf(r.f)));
      t.setRangeFontSize(pos, end, r.fs);
      t.setRangeFills(pos, end, [{ type: 'SOLID', color: hex(r.c), opacity: r.a === undefined ? 1 : r.a }]);
      t.setRangeLineHeight(pos, end, r.lh ? { unit: 'PIXELS', value: r.lh } : { unit: 'AUTO' });
      t.setRangeLetterSpacing(pos, end, { unit: 'PIXELS', value: r.ls || 0 });
      if (r.u) t.setRangeTextCase(pos, end, 'UPPER');
    }
    pos = end;
  }
  t.textAlignHorizontal = n.al || 'LEFT'; t.textAlignVertical = 'TOP';
  const pad = n.pad || [0, 0, 0, 0];
  const boxW = Math.max(2, n.w - pad[1] - pad[3]), boxH = Math.max(2, n.h - pad[0] - pad[2]);
  const lineH = n.runs[0].lh || n.runs[0].fs * 1.3;
  let dx = pad[3];
  if (boxH <= lineH + 1.5 && !chars.includes('\n')) {
    // single line in the app: never let Figma's slightly different metrics wrap it
    t.textAutoResize = 'WIDTH_AND_HEIGHT';
    if (n.al === 'CENTER') dx += (boxW - t.width) / 2; else if (n.al === 'RIGHT') dx += boxW - t.width;
  } else {
    t.textAutoResize = 'NONE'; t.resize(boxW + 2, boxH);
    t.textAutoResize = 'HEIGHT';
  }
  t.name = n.n || chars.slice(0, 40);
  return { node: t, dx, dy: pad[0] };
}
let count = 0;
async function make(n, parent, px, py) {
  let node, dx = 0, dy = 0;
  if (n.k === 'S') { const comp = ICONS[n.ic] ? await figma.getNodeByIdAsync(ICONS[n.ic]) : null; if (comp && comp.type === 'COMPONENT') { node = comp.createInstance(); } else { node = figma.createFrame(); node.fills = []; node.resize(Math.max(1, n.w), Math.max(1, n.h)); } node.name = n.n || 'icon'; if (n.op) node.opacity = n.op; }
  else if (n.k === 'T') { const r = await makeText(n); node = r.node; dx = r.dx; dy = r.dy; if (n.op) node.opacity = n.op; }
  else if (n.c && n.c.length) { node = figma.createFrame(); node.resize(Math.max(1, n.w), Math.max(1, n.h)); decorate(node, n); node.clipsContent = !!n.clip; node.name = n.n || 'group'; }
  else { node = figma.createRectangle(); node.resize(Math.max(1, n.w), Math.max(1, n.h)); decorate(node, n); node.name = n.n || (n.img ? 'image' : 'box'); }
  node.x = n.x - px + dx; node.y = n.y - py + dy;
  parent.appendChild(node); count++;
  if (n.rot) { const th = n.rot * Math.PI / 180, c = Math.cos(th), s = Math.sin(th); const cx = n.x + n.w / 2, cy = n.y + n.h / 2; const tlx = cx + (-n.w / 2) * c - (-n.h / 2) * s, tly = cy + (-n.w / 2) * s + (-n.h / 2) * c; node.relativeTransform = [[c, -s, tlx - px], [s, c, tly - py]]; }
  if (n.c) for (const c of n.c) await make(c, node, n.x, n.y);
  return node;
}
const created = [];
for (const u of UNITS) created.push((await make(u, FRAME, 0, 0)).id);
// hotspots back on top
for (const c of [...FRAME.children]) if (c.name.startsWith('→') || c.name.startsWith('swipe →')) FRAME.appendChild(c);
return { frame: FRAME_ID, chunk: CHUNK, nodes: count, created: created.length };
